import { html } from "../../node_modules/lit-html/lit-html.js"
import { getOffers } from "../data/offers.js"
//TODO replace with actual template

const catalogTemplate = (offers) => html`
  <section id="dashboard">
          <h2>Fun Facts</h2>
            ${offers.length > 0 ? html`${offers.map(offerTemplate)}` : html`<h2>No Fun Facts yet.</h2>`}
          <!-- Display a div with information about every post (if any)-->
        
    </section>`

const offerTemplate = (offer) => html`
    <div class="fact">
            <img src="${offer.imageUrl}" />
            <h3 class="category">${offer.title}</h3>
            <p class="description">${offer.description}</p>
            <a class="details-btn" href="${offer.requirements}">More Info</a>
    </div>`
          

export async function catalogPage(ctx) {
    const offers = await getOffers()
    ctx.render(catalogTemplate(offers))
}