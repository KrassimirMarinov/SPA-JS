import { html } from "../../node_modules/lit-html/lit-html.js"
import { createSubmitHandler } from "../util.js"
import { updateOffer } from "../data/offers.js"
import { getById } from "../data/offers.js"

const editTemplate = (offer, onEdit) => html`
<section id="edit">
          <div class="form">
            <h2>Edit Fact</h2>
            <form class="edit-form" @submit=${onEdit}>
              <input
                type="text"
                name="category"
                .value=${offer.title}
                id="job-category"
                placeholder="Category"
              />
              <input
                type="text"
                name="image-url"
                .value=${offer.imageUrl}
                id="image-url"
                placeholder="Image URL"
              />
              <textarea
                id="description"
                name="description"
                .value=${offer.description}
                placeholder="Description"
                rows="10"
                cols="50"
              ></textarea>
              <textarea
                id="additional-info"
                name="additional-info"
                .value = ${offer.requirements}
                placeholder="Additional Info"
                rows="10"
                cols="50"
              ></textarea>
            
              <button type="submit">Post</button>
            </form>
          </div>
        </section>`
export async function editPage(ctx) {
    const id = ctx.params.id
    const offer = await getById(id)

    ctx.render(editTemplate(offer, createSubmitHandler(onEdit)))


    async function onEdit({ title, imageUrl, description, requirements }){
        if ([title, imageUrl, description, requirements].some(x => x == "")) {
            return alert("Please fill all fields!")
        }
        await updateOffer(id,{ title, imageUrl, description, requirements })
        ctx.page.redirect(`/catalog/${id}`)
    }
}